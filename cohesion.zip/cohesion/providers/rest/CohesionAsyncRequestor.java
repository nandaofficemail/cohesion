package com.metlife.investments.cohesion.providers.rest;

import com.metlife.investments.cohesion.core.AsyncRequestor;
import com.metlife.investments.cohesion.providers.CohesionContext;

public class CohesionAsyncRequestor implements AsyncRequestor
{

    public CohesionAsyncRequestor(CohesionContext cohesionContext)
    {
	throw new UnsupportedOperationException();
	// TODO Auto-generated constructor stub
    }

}
