package com.metlife.investments.cohesion.core;

public interface AsyncRequestor
{

}
