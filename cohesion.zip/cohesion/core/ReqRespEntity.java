package com.metlife.investments.cohesion.core.registry;

public class ReqRespEntity
{

}
