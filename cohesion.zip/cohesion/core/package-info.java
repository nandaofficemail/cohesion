@XmlSchema(
        namespace="http://schemas.metlife.com/ServiceRegistry/PublisherRegistry/v1.0",
        elementFormDefault=XmlNsForm.QUALIFIED,
        xmlns={@XmlNs(prefix="d3p1", namespaceURI="http://schemas.metlife.com/ServiceRegistry/PublisherRegistryProperty")})
	
package com.metlife.investments.cohesion.core.registry;
import javax.xml.bind.annotation.*;
